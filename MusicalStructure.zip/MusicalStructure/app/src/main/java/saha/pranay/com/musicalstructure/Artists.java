package saha.pranay.com.musicalstructure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class Artists extends AppCompatActivity {
    TextView ArtistActTV;
    Button gotoAlbums, gotoNowPlaying, gotoPayments;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artists);
        ArtistActTV=(TextView)findViewById(R.id.ArtistActTV);
        ArtistActTV.setText("Artists...");

        gotoAlbums=(Button)findViewById(R.id.gotoAlbumsBT2);
        gotoNowPlaying=(Button)findViewById(R.id.gotoNowPlayingBT1);
        gotoPayments=(Button)findViewById(R.id.gotoPaymentsBT2);

        gotoAlbums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),Albums.class);
                startActivity(intent);
            }
        });

        gotoNowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),NowPlaying.class);
                startActivity(intent);
            }
        });

        gotoPayments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),Payments.class);
                startActivity(intent);
            }
        });
    }
}

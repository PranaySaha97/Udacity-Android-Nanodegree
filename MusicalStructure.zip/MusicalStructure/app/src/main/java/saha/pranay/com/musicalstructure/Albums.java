package saha.pranay.com.musicalstructure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Albums extends AppCompatActivity {
    TextView AlbumsActTV;
    Button gotoPayments, gotoNowPlaying, gotoArtist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_albums);
        AlbumsActTV=(TextView)findViewById(R.id.AlbumActTV);
        AlbumsActTV.setText("ALBUMS");

        gotoNowPlaying=(Button)findViewById(R.id.gotoNowPlayingBT3);
        gotoArtist=(Button)findViewById(R.id.gotoArtistBT3);
        gotoPayments=(Button)findViewById(R.id.gotoPaymentsBT3);

        gotoNowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),NowPlaying.class);
                startActivity(intent);
            }
        });

        gotoArtist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),Artists.class);
                startActivity(intent);
            }
        });

        gotoPayments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),Payments.class);
                startActivity(intent);
            }
        });
    }
}

package saha.pranay.com.musicalstructure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class NowPlaying extends AppCompatActivity {
    TextView nowPlayingAct_TV;
    ImageView playPause;
    Button gotoAlbums, gotoArtist, gotoPayments;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_now_playing);
        nowPlayingAct_TV=(TextView)findViewById(R.id.NowPlayingActivityTV);
        playPause=(ImageView)findViewById(R.id.playPause);
        gotoAlbums=(Button)findViewById(R.id.gotoAlbumsBT1);
        gotoArtist=(Button)findViewById(R.id.gotoArtistBT1);
        gotoPayments=(Button)findViewById(R.id.gotoPaymentsBT1);

        nowPlayingAct_TV.setText("Now Playing...\nPlaying your favourite");

        playPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    playPause.setImageResource(R.drawable.pause);
                Toast.makeText(v.getContext(),"Paused",Toast.LENGTH_LONG).show();


            }
        });

        gotoAlbums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),Albums.class);
                startActivity(intent);
            }
        });

        gotoArtist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),Artists.class);
                startActivity(intent);
            }
        });

        gotoPayments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),Payments.class);
                startActivity(intent);
            }
        });
    }

}

package saha.pranay.com.musicalstructure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView nowPlayingTV, ArtistTV, AlbumsTV, PaymentsTV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nowPlayingTV=(TextView)findViewById(R.id.NowPlayingTV);
        ArtistTV=(TextView)findViewById(R.id.ArtistTV);
        AlbumsTV=(TextView)findViewById(R.id.AlbumsTV);
        PaymentsTV=(TextView)findViewById(R.id.PaymentTv);

        nowPlayingTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(),"Now Playing",Toast.LENGTH_LONG).show();
                Intent intent=new Intent(v.getContext(),NowPlaying.class);
                startActivity(intent);
            }
        });

        ArtistTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(),"Artist",Toast.LENGTH_LONG).show();
                Intent intent=new Intent(v.getContext(),Artists.class);
                startActivity(intent);
            }
        });
        AlbumsTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(),"Albums",Toast.LENGTH_LONG).show();
                Intent intent=new Intent(v.getContext(),Albums.class);
                startActivity(intent);
            }
        });
        PaymentsTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(),"Payments",Toast.LENGTH_LONG).show();
                Intent intent=new Intent(v.getContext(),Payments.class);
                startActivity(intent);
            }
        });

    }
}

package saha.pranay.com.musicalstructure;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Payments extends AppCompatActivity {
    Button gotoAlbums, gotoNowPlaying, gotoArtist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payments);

        gotoAlbums=(Button)findViewById(R.id.gotoAlbumsBT3);
        gotoArtist=(Button)findViewById(R.id.gotoArtistBT2);
        gotoNowPlaying=(Button)findViewById(R.id.gotoNowPlayingBT2);

        gotoAlbums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),Albums.class);
                startActivity(intent);
            }
        });

        gotoArtist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),Artists.class);
                startActivity(intent);
            }
        });

        gotoNowPlaying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(),NowPlaying.class);
                startActivity(intent);
            }
        });
    }

}

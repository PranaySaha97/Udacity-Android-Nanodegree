package saha.pranay.com.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    TextView q1TextView,q2TextView,q3TextView,q4TextView,q5TextView,q6TextView,q7TextView,q8TextView,q9TextView,q10TextView;
    RadioButton q1r1,q1r2,q1r3,q1r4,q2r1,q2r2,q2r3,q2r4,q3r1,q3r2,q3r3,q3r4,q4r1,q4r2,q4r3,q4r4,q5r1,q5r2,q5r3,q5r4;
    CheckBox q6cb1,q6cb2,q6cb3,q6cb4,q7cb1,q7cb2,q7cb3,q7cb4;
    EditText q8et,q9et,q10et;
    TextView ScoreTv;
    RadioGroup rg1,rg2,rg3,rg4,rg5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        q1TextView=(TextView)findViewById(R.id.q1);
        q2TextView=(TextView)findViewById(R.id.q2);
        q3TextView=(TextView)findViewById(R.id.q3);
        q4TextView=(TextView)findViewById(R.id.q4);
        q5TextView=(TextView)findViewById(R.id.q5);
        q6TextView=(TextView)findViewById(R.id.q6);
        q7TextView=(TextView)findViewById(R.id.q7);
        q8TextView=(TextView)findViewById(R.id.q8);
        q9TextView=(TextView)findViewById(R.id.q9);
        q10TextView=(TextView)findViewById(R.id.q10);

        q1r1=(RadioButton)findViewById(R.id.q1r1);
        q1r2=(RadioButton)findViewById(R.id.q1r2);
        q1r3=(RadioButton)findViewById(R.id.q1r3);
        q1r4=(RadioButton)findViewById(R.id.q1r4);

        q2r1=(RadioButton)findViewById(R.id.q2r1);
        q2r2=(RadioButton)findViewById(R.id.q2r2);
        q2r3=(RadioButton)findViewById(R.id.q2r3);
        q2r4=(RadioButton)findViewById(R.id.q2r4);

        q3r1=(RadioButton)findViewById(R.id.q3r1);
        q3r2=(RadioButton)findViewById(R.id.q3r2);
        q3r3=(RadioButton)findViewById(R.id.q3r3);
        q3r4=(RadioButton)findViewById(R.id.q3r4);

        q4r1=(RadioButton)findViewById(R.id.q4r1);
        q4r2=(RadioButton)findViewById(R.id.q4r2);
        q4r3=(RadioButton)findViewById(R.id.q4r3);
        q4r4=(RadioButton)findViewById(R.id.q4r4);

        q5r1=(RadioButton)findViewById(R.id.q5r1);
        q5r2=(RadioButton)findViewById(R.id.q5r2);
        q5r3=(RadioButton)findViewById(R.id.q5r3);
        q5r4=(RadioButton)findViewById(R.id.q5r4);

        q6cb1=(CheckBox)findViewById(R.id.q6cb1);
        q6cb2=(CheckBox)findViewById(R.id.q6cb2);
        q6cb3=(CheckBox)findViewById(R.id.q6cb3);
        q6cb4=(CheckBox)findViewById(R.id.q6cb4);

        q7cb1=(CheckBox)findViewById(R.id.q7cb1);
        q7cb2=(CheckBox)findViewById(R.id.q7cb2);
        q7cb3=(CheckBox)findViewById(R.id.q7cb3);
        q7cb4=(CheckBox)findViewById(R.id.q7cb4);

        q8et=(EditText)findViewById(R.id.q8et);
        q9et=(EditText)findViewById(R.id.q9et);
        q10et=(EditText)findViewById(R.id.q10et);

        ScoreTv=(TextView)findViewById(R.id.ScoreTv);

        rg1=(RadioGroup)findViewById(R.id.rg1);
        rg2=(RadioGroup)findViewById(R.id.rg2);
        rg3=(RadioGroup)findViewById(R.id.rg3);
        rg4=(RadioGroup)findViewById(R.id.rg4);
        rg5=(RadioGroup)findViewById(R.id.rg5);

        setQuestion();

    }

    public void setQuestion(){
        String qs1,qs2,qs3,qs4,qs5,qs6,qs7,qs8,qs9,qs10;
        String q1o1,q1o2,q1o3,q1o4,q2o1,q2o2,q2o3,q2o4,q3o1,q3o2,q3o3,q3o4,q4o1,q4o2,q4o3,q4o4,q5o1,q5o2,q5o3,q5o4;
        String q6o1,q6o2,q6o3,q6o4,q7o1,q7o2,q7o3,q7o4;
        qs1="Q1. What is the capital of India ?";
        q1o1="Delhi";
        q1o2="Bangalore";
        q1o3="Mumbai";
        q1o4="Chennai";

        qs2="Q2. What is the national game of India ?";
        q2o1="Cricket";
        q2o2="Football";
        q2o3="Hockey";
        q2o4="Kabbadi";

        qs3="Q3. What is the national bird of India ?";
        q3o1="Peacock";
        q3o2="Cuckoo";
        q3o3="Crow";
        q3o4="Kingfisher";

        qs4="Q4. What is the national animal of India ?";
        q4o1="Cheetah";
        q4o2="Elephant";
        q4o3="Lion";
        q4o4="Tiger";

        qs5="Q5. How many states are there in India ?";
        q5o1="24";
        q5o2="25";
        q5o3="26";
        q5o4="28";

        qs6="Q6. Which of the following are states of India ?";
        q6o1="Karnataka";
        q6o2="Rhotak";
        q6o3="Gurgaon";
        q6o4="Nagaland";

        qs7="Q7. Which of the following are the food items ?";
        q7o1="Pizza";
        q7o2="Chair";
        q7o3="Cake";
        q7o4="Petrol";

        qs8="Q8. Where is Qutub Minar located ?";
        qs9="Q9. Who is the father of India ?";
        qs10="Q10. Bangalore is the capital of ?";

        q1TextView.setText(qs1);
        q1r1.setText(q1o1);
        q1r2.setText(q1o2);
        q1r3.setText(q1o3);
        q1r4.setText(q1o4);

        q2TextView.setText(qs2);
        q2r1.setText(q2o1);
        q2r2.setText(q2o2);
        q2r3.setText(q2o3);
        q2r4.setText(q2o4);

        q3TextView.setText(qs3);
        q3r1.setText(q3o1);
        q3r2.setText(q3o2);
        q3r3.setText(q3o3);
        q3r4.setText(q3o4);


        q4TextView.setText(qs4);
        q4r1.setText(q4o1);
        q4r2.setText(q4o2);
        q4r3.setText(q4o3);
        q4r4.setText(q4o4);

        q5TextView.setText(qs5);
        q5r1.setText(q5o1);
        q5r2.setText(q5o2);
        q5r3.setText(q5o3);
        q5r4.setText(q5o4);

        q6TextView.setText(qs6);
        q6cb1.setText(q6o1);
        q6cb2.setText(q6o2);
        q6cb3.setText(q6o3);
        q6cb4.setText(q6o4);

        q7TextView.setText(qs7);
        q7cb1.setText(q7o1);
        q7cb2.setText(q7o2);
        q7cb3.setText(q7o3);
        q7cb4.setText(q7o4);

        q8TextView.setText(qs8);
        q9TextView.setText(qs9);
        q10TextView.setText(qs10);


    }

    int score=0;

    public void checkQ6(){
        if(q6cb1.isChecked() && q6cb4.isChecked() &&  !q6cb2.isChecked() && q6cb3.isChecked()) {
            score++;
        }
        else{
            score=score;
        }

    }
    public void checkQ7(){
        if(q7cb1.isChecked() && q7cb3.isChecked() && !q7cb2.isChecked() && !q7cb4.isChecked()) {
            score++;
        }
        else{
            score=score;
        }
    }
    public void checkQ8(){
        String resp=q8et.getText().toString();
        int res=resp.compareToIgnoreCase("delhi");
        if(res==0){
            score++;
        }
        else{
            score=score;
        }
    }
    public void checkQ9(){
        String resp=q9et.getText().toString();
        int res=resp.compareToIgnoreCase("mk gandhi");
        if(res==0){
            score++;
        }
        else{
            score=score;
        }
    }
    public void checkQ10(){
        String resp=q10et.getText().toString();
        int res=resp.compareToIgnoreCase("karnataka");
        if(res==0){
            score++;
        }
        else{
            score=score;
        }
    }
    public void q1RadioButton(View view){
        if(view.getId()==R.id.q1r1){
            score++;
        }
        else{
            score=score;
        }
    }

    public void q2RadioButton(View view){
        if(view.getId()==R.id.q2r3){
            score++;
        }
        else{
            score=score;
        }
    }

    public void q3RadioButton(View view){
        if(view.getId()==R.id.q3r1){
            score++;
        }
    }

    public void q4RadioButton(View view){
        if(view.getId()==R.id.q4r4){
            score++;
        }
        else{
            score=score;
        }
    }

    public void q5RadioButton(View view){
        if(view.getId()==R.id.q5r3){
            score++;
        }
        else{
            score=score;
        }
    }

    public void ResetView(){
        q9et.setText("");
        q8et.setText("");
        q10et.setText("");
        q6cb1.setChecked(false);
        q6cb2.setChecked(false);
        q6cb3.setChecked(false);
        q6cb4.setChecked(false);
        q7cb1.setChecked(false);
        q7cb2.setChecked(false);
        q7cb3.setChecked(false);
        q7cb4.setChecked(false);

        rg1.clearCheck();
        rg2.clearCheck();
        rg3.clearCheck();
        rg4.clearCheck();
        rg5.clearCheck();
        score=0;
    }

    public void submitHit(View view){
        checkQ6();
        checkQ7();
        checkQ8();
        checkQ9();
        checkQ10();
        String disp="Your Score: "+score+"/10";
        Toast.makeText(this, disp, Toast.LENGTH_LONG).show();
        ResetView();
    }
}

package saha.pranay.com.bangaloreguide;

public class Word {
    private int mData, mDataInfo;
    private int mImageRresourceId=NO_IMAGE_PROVIDED;
    private static final int NO_IMAGE_PROVIDED=-1;

    public Word(int data, int dataInfo, int imageRresourceId){
        mDataInfo=dataInfo;
        mData=data;
        mImageRresourceId=imageRresourceId;
    }

    public int getmDataInfo() {
        return mDataInfo;
    }

    public int getmData() {
        return mData;
    }

    public int getmImageRresourceId() {
        return mImageRresourceId;
    }

    public boolean hadImage(){
        return mImageRresourceId!=NO_IMAGE_PROVIDED;
    }
}

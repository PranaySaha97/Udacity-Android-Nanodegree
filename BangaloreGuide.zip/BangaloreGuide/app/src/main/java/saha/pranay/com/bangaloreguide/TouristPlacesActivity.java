package saha.pranay.com.bangaloreguide;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class TouristPlacesActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tourist_places);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        listView=(ListView)findViewById(R.id.touristPlace_LV);
        ArrayList<Word> touristList=new ArrayList<>();

        touristList.add(new Word(R.string.tp_1,R.string.tp_1_, R.drawable.family_older_sister));
        touristList.add(new Word(R.string.tp_2,R.string.tp_2_,R.drawable.family_grandfather));
        touristList.add(new Word(R.string.tp_3,R.string.tp_3_,R.drawable.family_daughter));
        touristList.add(new Word(R.string.event_4,R.string.tp_4_,R.drawable.family_older_brother));
        touristList.add(new Word(R.string.tp_5,R.string.tp_5_,R.drawable.family_younger_brother));
        touristList.add(new Word(R.string.tp_6,R.string.tp_6_,R.drawable.family_son));
        touristList.add(new Word(R.string.tp_7,R.string.tp_7_,R.drawable.family_mother));
        touristList.add(new Word(R.string.tp_8,R.string.tp_8_,R.drawable.family_father));
        touristList.add(new Word(R.string.tp_9,R.string.tp_9_,R.drawable.family_younger_sister));
        touristList.add(new Word(R.string.tp_10,R.string.tp_10_,R.drawable.family_grandmother));
        touristList.add(new Word(R.string.tp_11,R.string.tp_11_,R.drawable.number_eight));
        touristList.add(new Word(R.string.tp_12,R.string.tp_12_,R.drawable.number_ten));
        touristList.add(new Word(R.string.tp_13,R.string.tp_13_,R.drawable.number_nine));
        touristList.add(new Word(R.string.tp_14,R.string.tp_14_,R.drawable.number_four));

        EventAdapter eventAdapter=new EventAdapter(this, touristList);
        listView.setAdapter(eventAdapter);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.tourist_places, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Toast.makeText(this, "Settings", Toast.LENGTH_SHORT);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_Home) {
            Intent intent=new Intent(this, MainActivity.class);
            startActivity(intent);
            Toast.makeText(getBaseContext(),R.string.home_head,Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_TouristPlaces) {
            Intent intent=new Intent(this, TouristPlacesActivity.class);
            startActivity(intent);
            Toast.makeText(getBaseContext(),R.string.tp_head,Toast.LENGTH_SHORT).show();

        } else if (id == R.id.nav_Events) {
            Intent intent=new Intent(this, EventsActivity.class);
            startActivity(intent);
            Toast.makeText(getBaseContext(), R.string.events_head, Toast.LENGTH_SHORT).show();

        } else if (id == R.id.nav_Restaurants) {
            Intent intent=new Intent(this, RestaurantActivity.class);
            startActivity(intent);
            Toast.makeText(getBaseContext(),R.string.rest_head,Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_Engineering){
            Intent intent=new Intent(this, EngineeringActvity.class);
            startActivity(intent);
            Toast.makeText(getBaseContext(),R.string.eng_head, Toast.LENGTH_SHORT).show();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}

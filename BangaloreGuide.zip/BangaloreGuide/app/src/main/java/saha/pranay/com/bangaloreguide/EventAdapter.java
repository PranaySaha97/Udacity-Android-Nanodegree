package saha.pranay.com.bangaloreguide;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class EventAdapter extends ArrayAdapter<Word> {

    public EventAdapter(Context context, ArrayList<Word> words) {
        super(context, 0, words);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_str, parent, false);
        }

        Word currentWord = getItem(position);


        TextView events_TV = (TextView) listItemView.findViewById(R.id.data);

        events_TV.setText(currentWord.getmData());
        events_TV.setVisibility(View.VISIBLE);

        TextView events_TV_info =(TextView)listItemView.findViewById(R.id.data_Info);
        events_TV_info.setText(currentWord.getmDataInfo());
        events_TV_info.setVisibility(View.VISIBLE);


        ImageView imageView = (ImageView) listItemView.findViewById(R.id.image);

        if (currentWord.hadImage()) {

            imageView.setImageResource(currentWord.getmImageRresourceId());

            imageView.setVisibility(View.VISIBLE);
        } else {

            imageView.setVisibility(View.GONE);
        }



        return listItemView;
    }
}

package saha.pranay.com.habittrackerapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "tracker.db";
    private static final int DB_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_TABLE = "CREATE TABLE " + Contract.DataEntry.TABLE_NAME + " ("
                + Contract.DataEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Contract.DataEntry.COLUMN_HABIT_NAME + " TEXT NOT NULL, "
                + Contract.DataEntry.COLUMN_HABIT_FREQUENCY + " INTEGER NOT NULL, "
                + Contract.DataEntry.COLUMN_HABIT_STATUS + " INTEGER NOT NULL DEFAULT 0);";

        db.execSQL(CREATE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}

package saha.pranay.com.habittrackerapp;

import android.provider.BaseColumns;

public final class Contract {

    private Contract() {
    }

    public static final class DataEntry implements BaseColumns {
        public final static String TABLE_NAME = "habits";
        public final static String _ID = BaseColumns._ID;
        public final static String COLUMN_HABIT_NAME = "name";
        public final static String COLUMN_HABIT_FREQUENCY = "frequency";
        public final static String COLUMN_HABIT_STATUS = "status";
        public static final int HABIT_STATUS_UNKNOWN = 0;
        public static final int HABIT_STATUS_DONE = 1;
        public static final int HABIT_STATUS_NOT_DONE = 2;

    }

}

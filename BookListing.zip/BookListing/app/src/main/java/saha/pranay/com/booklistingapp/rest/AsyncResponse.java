package saha.pranay.com.booklistingapp.rest;

import saha.pranay.com.booklistingapp.model.Book;

import java.util.ArrayList;

public interface AsyncResponse {
    void processFinish(ArrayList<Book> bookArrayList);
}
